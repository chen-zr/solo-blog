title: Windows MySQL 安装
date: '2019-07-28 00:08:53'
updated: '2019-07-28 00:08:53'
tags: [数据库, DB, MySQL]
permalink: /articles/2019/07/28/1564243733459.html
---
![mark](http://7niu.chensr.cn/blog/20190728/6feDniVNLuM6.png?imageslim)

### Windows
#### 下载安装包
这里推荐 mysql 5.7 版本的，或者是 mysql 8.0 版本的。
下载时和下载 JDK 一样，需要登陆 Oracle 账号。
![mark](http://7niu.chensr.cn/blog/20190727/NcpwtMmG6ldt.png?imageslim)

#### 解压
解压下载好的 Mysql zip 压缩包，假定解压目录为 D:\develop\mysql-8.0.11

#### 配置信息
到 MySQL 安装根目录，找到 my.ini 文件，如果没有，就新建一个，文件内容如下
```
[mysql]
# 设置mysql客户端默认字符集
default-character-set=utf8
[mysqld]
# 设置3306端口
port = 3306
# 设置mysql的安装目录
basedir= D:\develop\mysql-8.0.11
# 设置mysql数据库的数据的存放目录
datadir= D:\develop\mysql-8.0.11\data
# 允许最大连接数
max_connections=20
# 服务端使用的字符集默认为8比特编码的latin1字符集
character-set-server=utf8
# 创建新表时将使用的默认存储引擎
default-storage-engine=INNODB
```
#### data 目录
进入 MySQL 的根目录，在根目录下创建一个名为 data 的空文件夹

#### 安装服务
以管理员方式打开 CMD。

![mark](http://7niu.chensr.cn/blog/20190727/KQA1i7UXNzNX.png?imageslim)

cd 到 MySQL 的 bin 目录中，执行安装命令 mysqld --initialize-insecure --user=mysql

#### 将 MySQL 安装为系统服务
依然在管理员cmd窗口的bin目录下，执行 mysqld install 命令安装。完成后会提示安装成功。

#### 将 MySQL 设置为随系统自启
按下 Win + r，输入 services.msc，进入 Windows 系统服务后，按下 m，找到刚刚安装的系统服务，右击属性，将其设置为自动启动

![mark](http://7niu.chensr.cn/blog/20190728/s0Xw4Tfeg6D5.png?imageslim)

#### 安装成功
使用 navicat 工具连接即可，初始连接时，MySQL 默认密码为空，连接成功后，请先修改密码。

### Linux 