title: Dubbo入门（3）- HelloWorld、监控中心和 SpringBoot
date: '2019-07-11 22:01:02'
updated: '2019-07-11 22:01:02'
tags: [dubbo, 分布式, SOA, 微服务]
permalink: /articles/2019/07/11/1562853662735.html
---
![mark](http://7niu.chensr.cn/blog/20190711/qocemNSvH9ov.png?imageslim)

### 提个小需求
某电商系统，订单服务需要调用用户服务来获取用户的所有地址。
因此现在需要两个模块：
- 订单服务 web 模块
- 用户服务 service 模块
测试逾期结果：订单服务 web 模块在 A 服务器，用户服务模块在 B 服务器，A 可以远程调用 B 服务器的服务。

### 工程架构
#### 分包
服务接口、服务模型（bean）、服务异常，均放在 API 包中，因为服务模型和异常也是 API 的一部分。同时这样也符合**分包原则：重用发布等价原则（REP）、共同重用原则（CRP）**。

如何需要，可以在 API 包中放置一份 Spring 引用配置，这样使用方只需在 Spring 加载过程中引用此配置文件，建议放在模块的包目录下，以免冲突。

#### 粒度
服务接口尽可能最大粒度，每个服务方法应代表一个功能，而不是某个功能的一个步骤，否则将面临分布式事务问题。

服务接口建议以业务场景为单位划分，并对相近的业务做抽象，防止接口数量爆炸。

不建议使用过于抽象的接口定义，如：Map query(Map)，这样的接口没有明确的语义，会给后期维护带来不便。
![mark](http://7niu.chensr.cn/blog/20190701/xQ42dW6vseVi.png?imageslim)

#### 创建模块
![mark](http://7niu.chensr.cn/blog/20190701/MogopuIBRQJr.png?imageslim)

##### gmall-interface 公共接口层
Bean模型
```java
public class UserAddress implements Serializable{
    private Integer id;
    private String userAddress;
    private String userId;
    private String consignee;
    private String phoneNum;
    private String isDefault;
}
```

Service 接口
```java
public List<UserAddress> getUserAddressList(String userId);
```
##### gmall-user 用户模块
pom
```xml
<dependencies>
  	<dependency>
  		<groupId>com.atguigu.dubbo</groupId>
  		<artifactId>gmall-interface</artifactId>
  		<version>0.0.1-SNAPSHOT</version>
  	</dependency>
</dependencies>
```

Service：
```java
public class UserServiceImpl implements UserService {
		
	@Override
	public List<UserAddress> getUserAddressList(String userId) {
		// TODO Auto-generated method stub
		return userAddressDao.getUserAddressById(userId);
	}
}
```
##### gmall-order-web 订单模块
pom.xml
```xml
<dependencies>
  	<dependency>
  		<groupId>com.atguigu.dubbo</groupId>
  		<artifactId>gmall-interface</artifactId>
  		<version>0.0.1-SNAPSHOT</version>
  	</dependency>
</dependencies>
```
OrderService
```java
public class OrderService {
	UserService userService;
	/**
	 * 初始化订单，查询用户的所有地址并返回
	 * @param userId
	 * @return
	 */
	public List<UserAddress> initOrder(String userId){
		return userService.getUserAddressList(userId);
	}
}
```
当然，现在这样我们是无法直接调用的。

### Dubbo 改造
#### 改造 gmall-user 作为服务提供者
pom.xml
```xml
<!-- 引入dubbo -->
<dependency>
    <groupId>com.alibaba</groupId>
    <artifactId>dubbo</artifactId>
    <version>2.6.2</version>
</dependency>
<!-- 由于我们使用zookeeper作为注册中心，所以需要操作zookeeper
dubbo 2.6以前的版本引入zkclient操作zookeeper 
dubbo 2.6及以后的版本引入curator操作zookeeper
下面两个zk客户端根据dubbo版本2选1即可-->
<dependency>
    <groupId>com.101tec</groupId>
    <artifactId>zkclient</artifactId>
    <version>0.10</version>
</dependency>
<!-- curator-framework -->
<dependency>
    <groupId>org.apache.curator</groupId>
    <artifactId>curator-framework</artifactId>
    <version>2.12.0</version>
</dependency>
```

服务提供者，需要新建一个 dubbo 的 xml 配置文件
```xml
<!--当前应用的名字  -->
<dubbo:application name="gmall-user"></dubbo:application>
<!--指定注册中心的地址  -->
<dubbo:registry address="zookeeper://118.24.44.169:2181" />
<!--使用dubbo协议，将服务暴露在20880端口  -->
<dubbo:protocol name="dubbo" port="20880" />
<!-- 指定需要暴露的服务 -->
<dubbo:service interface="com.atguigu.gmall.service.UserService" ref="userServiceImpl" />
```

启动服务：
```java
public static void main(String[] args) throws IOException {
	ClassPathXmlApplicationContext context = 
	new ClassPathXmlApplicationContext("classpath:spring-beans.xml");
	System.in.read(); 
}
```

#### 改造 gmall-order-web 作为服务消费者
pom 引入 dubbo
```xml
<!-- 引入dubbo -->
<dependency>
	<groupId>com.alibaba</groupId>
	<artifactId>dubbo</artifactId>
	<version>2.6.2</version>
</dependency>
<!-- 由于我们使用zookeeper作为注册中心，所以需要引入zkclient和curator操作zookeeper -->
<dependency>
	<groupId>com.101tec</groupId>
	<artifactId>zkclient</artifactId>
	<version>0.10</version>
</dependency>
<!-- curator-framework -->
<dependency>
	<groupId>org.apache.curator</groupId>
	<artifactId>curator-framework</artifactId>
	<version>2.12.0</version>
</dependency>
```

dubbo xml 中配置消费者信息
```xml
<!-- 应用名 -->
<dubbo:application name="gmall-order-web"></dubbo:application>
<!-- 指定注册中心地址 -->
<dubbo:registry address="zookeeper://118.24.44.169:2181" />
<!-- 生成远程服务代理，可以和本地bean一样使用demoService -->
<dubbo:reference id="userService" interface="com.atguigu.gmall.service.UserService"></dubbo:reference>
```

#### 测试调用
访问gmall-order-web的initOrder请求，会调用UserService获取用户地址；
调用成功。说明我们order已经可以调用远程的UserService了；

使用注解：
服务提供方需使用 Dubbo 的 @Service；
消费方需使用 @Reference

### 监控中心
#### dubbo-admin
图形化服务管理页面，安装时需指定服务注册地址，可以从注册中心获取到所有服务提供者和消费者，从而进行配置。

#### dubbo-monitor-simple
简单的监控中心

### SpringBoot
引入依赖
```xml
<dependency>
    <groupId>com.alibaba.boot</groupId>
    <artifactId>dubbo-spring-boot-starter</artifactId>
    <version>0.2.0</version>
</dependency>
```
配置提供者 properties
```xml
dubbo.application.name=gmall-user
dubbo.registry.protocol=zookeeper
dubbo.registry.address=192.168.67.159:2181
dubbo.scan.base-package=com.atguigu.gmall
dubbo.protocol.name=dubbo
application.name就是服务名，不能跟别的dubbo提供端重复
registry.protocol 是指定注册中心协议
registry.address 是注册中心的地址加端口号
protocol.name 是分布式固定是dubbo,不要改。
base-package  注解方式要扫描的包
```

配置消费者 properties
```xml
dubbo.application.name=gmall-order-web
dubbo.registry.protocol=zookeeper
dubbo.registry.address=192.168.67.159:2181
dubbo.scan.base-package=com.atguigu.gmall
dubbo.protocol.name=dubbo
```

