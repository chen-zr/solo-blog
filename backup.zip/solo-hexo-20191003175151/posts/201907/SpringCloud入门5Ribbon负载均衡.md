title: Spring Cloud入门（5）- Ribbon负载均衡
date: '2019-07-09 21:38:44'
updated: '2019-07-09 22:24:29'
tags: [微服务, SC, SpringCloud, SOA]
permalink: /articles/2019/07/09/1562679524694.html
---
![](http://7niu.chensr.cn/blog/20190709/vHyRIOCTIhaj.png?imageslim)

### 概述
#### Ribbon 是什么
Spring Cloud Ribbon 是基于 Netflix Ribbon 实现的一套**客户端**负载均衡的工具。

简单的说，就是在配置文件中列出Load Balancer（简称LB）后面所有的机器，Ribbon会自动的帮助你基于某种规则（如简单轮询，随机连接等）去连接这些机器。我们也很容易使用Ribbon实现自定义的负载均衡算法。

#### Ribbon 能干嘛
负载均衡简单的说就是将用户的请求平摊的分配到多个服务上，从而达到系统的HA。常见的负载均衡有软件Nginx，LVS，硬件 F5等。

##### 集中式LB
服务的消费方和提供方之间使用独立的LB设施(可以是硬件，如F5, 也可以是软件，如nginx)，由该设施负责把访问请求通过某种策略转发至服务的提供方；

##### 进程内LB
将LB逻辑集成到消费方，消费方从服务注册中心获知有哪些地址可用，然后自己再从这些地址中选择出一个合适的服务器。`Ribbon就属于进程内LB`，它只是一个类库，集成于消费方进程，消费方通过它来获取到服务提供方的地址。

### Ribbon配置初步
#### 修改 microservicecloud-consumer-dept-80 工程
pom 增加配置：
```xml
<!-- Ribbon相关 -->
<dependency>
  <groupId>org.springframework.cloud</groupId>
  <artifactId>spring-cloud-starter-eureka</artifactId>
</dependency>
<dependency>
  <groupId>org.springframework.cloud</groupId>
  <artifactId>spring-cloud-starter-ribbon</artifactId>
</dependency>
<dependency>
  <groupId>org.springframework.cloud</groupId>
  <artifactId>spring-cloud-starter-config</artifactId>
</dependency>
```

yml 增加配置，将 consumer 添加到注册中心，追加另外两个注册中心地址：
```yml
eureka:
  client:
    register-with-eureka: false
    service-url: 
      defaultZone: http://eureka7001.com:7001/eureka/,http://eureka7002.com:7002/eureka/,http://eureka7003.com:7003/eureka/
```
对 ConfigBean 进行新注解 @LoadBalanced，获得 Rest 时加入 Ribbon 的配置
```java
package com.atguigu.springcloud.cfgbeans;

import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;
 
@Configuration
public class ConfigBean {
  @Bean
  @LoadBalanced
  public RestTemplate getRestTemplate() {
    return new RestTemplate();
  }
}
```

主启动类加 @EnableEurekaClient
```java
package com.atguigu.springcloud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
 
 
@SpringBootApplication
@EnableEurekaClient
public class DeptConsumer80_App {
  public static void main(String[] args) {
    SpringApplication.run(DeptConsumer80_App.class, args);
  }
}
```

修改 DeptController_Consumer 客户端访问类
```java
package com.atguigu.springcloud.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import com.atguigu.springcloud.entities.Dept;
 
@RestController
public class DeptController_Consumer {
  //private static final String REST_URL_PREFIX = "http://localhost:8001";
  private static final String REST_URL_PREFIX = "http://MICROSERVICECLOUD-DEPT";
  
  @Autowired
  private RestTemplate restTemplate;
  
  @RequestMapping(value="/consumer/dept/add")
  public boolean add(Dept dept) {
    return restTemplate.postForObject(REST_URL_PREFIX+"/dept/add", dept, Boolean.class);
  }
  
  @RequestMapping(value="/consumer/dept/get/{id}")
  public Dept get(@PathVariable("id") Long id) {
    return restTemplate.getForObject(REST_URL_PREFIX+"/dept/get/"+id, Dept.class);
  }
  
  @SuppressWarnings("unchecked")
  @RequestMapping(value="/consumer/dept/list")
  public List<Dept> list() {
    return restTemplate.getForObject(REST_URL_PREFIX+"/dept/list", List.class);
  } 
  
  //测试@EnableDiscoveryClient,消费端可以调用服务发现
  @RequestMapping(value="/consumer/dept/discovery") 
  public Object discovery() {
    return restTemplate.getForObject(REST_URL_PREFIX+"/dept/discovery", Object.class);
  }
}
```
先启动3个 eureka 集群后，再启动 microservicecloud-provider-dept-8001 并注册进 eureka，再启动microservicecloud-consumer-dept-80

测试：
http://localhost/consumer/dept/get/1
http://localhost/consumer/dept/list
http://localhost/consumer/dept/add?dname=大数据部

Ribbon 和 Eureka 整合后 Consumer 可以直接调用服务而不用再关心地址和端口号

### Ribbon负载均衡
#### 架构说明
![mark](http://7niu.chensr.cn/blog/20190709/fJUCcbixxfAl.png?imageslim)

Ribbon在工作时分成两步：

- 第一步先选择 EurekaServer ，它优先选择在同一个区域内负载较少的 server
- 第二步再根据用户指定的策略，在从 server 取到的服务注册列表中选择一个地址，其中 Ribbon 提供了多种策略：比如轮询、随机和根据响应时间加权。

#### 增加 provider
- 参考 microservicecloud-provider-dept-8001，新建两份，分别命名为8002，8003
- 新建8002/8003数据库，各自微服务分别连各自的数据库
- yml 中与8001相比，端口不同，数据库连接不同，这是为了更直观的看到负载均衡调的不同的服务
- yml 中对外暴露的服务实例名必须相同

启动3个 Eureka 集群，启动3个 provider 提供服务，并自测：
http://localhost:8001/dept/list
http://localhost:8002/dept/list
http://localhost:8003/dept/list

启动 microservicecloud-consumer-dept-80，然后客户端通过 Ribbon 完成负载均衡并访问上一步的 Dept 微服务，注意观察看到返回的数据库名字，各不相同，负载均衡实现。

Ribbon 其实就是一个软负载均衡的客户端组件，他可以和其他所需请求的客户端结合使用，和 eureka 结合只是其中的一个实例。

### Ribbon 核心组件 IRule
根据特定算法中从服务列表中选取一个要访问的服务，其中有：

- RoundRobinRule 轮询
- RandomRule 随机
- AvailabilityFilteringRule 会先过滤掉由于多次访问故障而处于断路器跳闸状态的服务，还有并发的连接数量超过阈值的服务，然后对剩余的服务列表按照轮询策略进行访问
- WeightedResponseTimeRule 根据平均响应时间计算所有服务的权重，响应时间越快服务权重越大被选中的概率越高。刚启动时如果统计信息不足，则使用 RoundRobinRule 策略，等统计信息足够，会切换到WeightedResponseTimeRule
- RetryRule 先按照 RoundRobinRule 的策略获取服务，如果获取服务失败则在指定时间内会进行重试，获取可用的服务
- BestAvailableRule 会先过滤掉由于多次访问故障而处于断路器跳闸状态的服务，然后选择一个并发量最小的服务
- ZoneAvoidanceRule 默认规则,复合判断server所在区域的性能和server的可用性选择服务器

### Ribbon自定义
#### 修改 microservicecloud-consumer-dept-80
主启动类添加 @RibbonClient
```java
@RibbonClient(name="MICROSERVICECLOUD-DEPT",configuration=MySelfRule.class)
```

#### 注意配置细节
官方文档明确给出了警告：
这个自定义配置类不能放在 @ComponentScan 所扫描的当前包下以及子包下，否则我们自定义的这个配置类就会被所有的Ribbon客户端所共享，也就是说我们达不到特殊化定制的目的了。

#### 步骤
新建 package com.atguigu.myrule，新建自定义 Robbin 规则类
```java
package com.atguigu.myrule;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import com.netflix.loadbalancer.IRule;
import com.netflix.loadbalancer.RandomRule;
 
@Configuration
public class MySelfRule {
  @Bean
  public IRule myRule() {
    //Ribbon默认是轮询，这里自定义为随机
    return new RandomRule();
  }
}
```
修改主启动类
```java
@RibbonClient(name="MICROSERVICECLOUD-DEPT",configuration=MySelfRule.class)
```
http://localhost/consumer/dept/list 随机，不是轮询

#### 继续自定义
依旧轮询策略，但是加上新需求，每个服务器要求被调用5次。也即以前是每台机器一次，现在是每台机器5次
参考源码修改为我们需求要求的 RandomRule_ZY
```java
package com.atguigu.myrule;

import java.util.List;
import java.util.Random;
import com.netflix.client.config.IClientConfig;
import com.netflix.loadbalancer.AbstractLoadBalancerRule;
import com.netflix.loadbalancer.ILoadBalancer;
import com.netflix.loadbalancer.Server;
 
public class RandomRule_ZY extends AbstractLoadBalancerRule {

  //总共被调用的次数，目前要求每台被调用5次
  private int total = 0;
  //当前提供服务的机器号
  private int currentIndex = 0;
  
    public Server choose(ILoadBalancer lb, Object key) {
        if (lb == null) {
            return null;
        }
        Server server = null;
 
        while (server == null) {
            if (Thread.interrupted()) {
                return null;
            }
            List<Server> upList = lb.getReachableServers();
            List<Server> allList = lb.getAllServers();
 
            int serverCount = allList.size();
            if (serverCount == 0) {
                /*
                 * No servers. End regardless of pass, because subsequent passes
                 * only get more restrictive.
                 */
                return null;
            }
 
            
//            int index = rand.nextInt(serverCount);
//            server = upList.get(index);
            if(total < 5)
            {
            server = upList.get(currentIndex);
            total++;
            }else {
            total = 0;
            currentIndex++;
            if(currentIndex >= upList.size())
            {
              currentIndex = 0;
            }
            
            }
            
            
            
 
            if (server == null) {
                /*
                 * The only time this should happen is if the server list were
                 * somehow trimmed. This is a transient condition. Retry after
                 * yielding.
                 */
                Thread.yield();
                continue;
            }
 
            if (server.isAlive()) {
                return (server);
            }
 
            // Shouldn't actually happen.. but must be transient or a bug.
            server = null;
            Thread.yield();
        }
        return server;
    }
 
  @Override
  public Server choose(Object key) {
    return choose(getLoadBalancer(), key);
  }
 
  @Override
  public void initWithNiwsConfig(IClientConfig clientConfig) {
   
  }
}
 
```

MySelfRule.java 修改
```java
// 自定义为每个机器被访问5次
return new RandomRule_ZY();
```

测试成功。~~~~