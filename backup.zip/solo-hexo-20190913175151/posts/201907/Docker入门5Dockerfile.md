title: Docker入门（5）- Dockerfile
date: '2019-07-09 20:44:37'
updated: '2019-07-09 21:34:47'
tags: [docker, 容器]
permalink: /articles/2019/07/09/1562676277707.html
---
![](http://7niu.chensr.cn/blog/20190709/vjse48VX7QFq.png?imageslim)

### Dockerfile概念
#### 是什么
Dockerfile 是用来构建 Docker 镜像的构建文件，是由一系列命令和参数构成的脚本。

#### 怎么用
- 编写 Dockerfile 文件
- docker build （build 镜像）
- docker run （使用镜像创建并运行容器）

### 构建过程解析
#### 基础知识
- 每条保留字指令都必须为大写字母且后面要跟随至少一个参数
- 指令按照从上到下，顺序执行
- \#表示注释
- 每条指令都会创建一个新的镜像层，并对镜像进行提交

#### 大致流程
- dokcer 从基础镜像运行一个容器
- 执行一条指令对容器做出修改
- 执行类似 docker commit 命令提交为一个新的镜像层
- 基于上一步提交的镜像再生成一个新的容器
- 执行下一条指令对新的容器做出修改
- 以此类推直到命令都执行完

#### 小总结
- Dockerfile 是软件的原材料，docker 镜像是交付品，docker容器可以认为是软件的运行态
- Dockerfile 面向开发，Docker 镜像为交付标准，Docker 容器涉及部署和运维，三者缺一不可，合理充当 docker 体系的基石
- Dockerfile 定义了进程需要的一切东西，包括应用、环境变量、依赖包、运行时环境、动态链接库，操作系统发行版，服务进程和内核进程等等

### Dockerfile 体系结构
- `FROM` 基础镜像，当前新镜像是基于哪个镜像的
- `MAINTAINER` 镜像维护者的姓名和邮箱地址
- `RUN` 容器构建时需要运行的命令
- `EXPOSE` 当前容器对外暴露出的端口
- `WORKDIR` 指定在创建容器后，终端默认登陆的进来工作目录，一个落脚点
- `ENV` 用来在构建镜像过程中设置环境变量
- `ADD` 将宿主机目录下的文件拷贝进镜像且ADD命令会自动处理URL和解压tar压缩包
- `COPY` 类似ADD，拷贝文件和目录到镜像中。将从构建上下文目录中 <源路径> 的文件/目录复制到新的一层的镜像内的 <目标路径> 位置
- `VOLUME` 容器数据卷，用于数据保存和持久化工作
- `CMD` 指定一个容器启动时要运行的命令
  - ![mark](http://7niu.chensr.cn/blog/20190619/zQqvjHfGxzhG.png?imageslim)
  - Dockerfile 中可以有多个 CMD 指令，但只有最后一个生效，CMD 会被 docker run 之后的参数替换
- `ENTRYPOINT` 指定一个容器启动时要运行的命令，ENTRYPOINT 的目的和 CMD 一样，都是在指定容器启动程序及参数
- `ONBUILD` 当构建一个被继承的Dockerfile时运行命令，父镜像在被子继承后父镜像的onbuild被触发
- ![mark](http://7niu.chensr.cn/blog/20190619/NCYfHTNFrcNV.png?imageslim)

### Dockerfile 案例
#### Base镜像(scratch)
Docker Hub 中 99% 的镜像都是通过在 base 镜像中安装和配置需要的软件构建出来的。
#### 自定义镜像 mycentos
##### 编写
初始 centos 镜像默认路径是根目录，且默认不支持 vim，默认不支持 ifconfig。

```shell
FROM centos
MAINTAINER chensr<codechensr@163.com>
 
ENV MYPATH /usr/local
WORKDIR $MYPATH
 
RUN yum -y install vim
RUN yum -y install net-tools
 
EXPOSE 80
 
CMD echo $MYPATH
CMD echo "success--------------ok"
CMD /bin/bash
```

##### 构建
命令：`docker build -t mycentos:1.3 .`注意最后有一个点，代表当前目录

构建完成后，会提示 Successfully built 镜像ID

##### 运行
命令：`docker run -it mycentos:1.3`
进入 mycentos 之后，使用 vim 和 ifconfig 命令成功

##### 列出镜像的变更历史
`docker history 镜像名`

#### CMD/ENTRYPOINT 镜像案例
都是指定一个容器启动时要运行的命令

##### CMD
Dockerfile 中可以有多个 CMD 指令，但只有最后一个生效，CMD 会被 docker run 之后的参数替换

##### ENTRYPOINT 
docker run 之后的参数会被当做参数传递给 ENTRYPOINT，之后形成新的命令组合
``` shell
FROM centos
RUN yum install -y curl
CMD [ "curl", "-s", "http://ip.cn" ]
```
![mark](http://7niu.chensr.cn/blog/20190620/U58NxC8JrRdW.png?imageslim)

再来看看 ENTRYPOINT 怎么接收 docker 命令的传参
![mark](http://7niu.chensr.cn/blog/20190620/t3IuqerTXeyV.png?imageslim)

可以看到可执行文件找不到的报错，executable file not found。
之前我们说过，跟在镜像名后面的是 command，运行时会替换 CMD 的默认值。

因此这里的 -i 替换了原来的 CMD，而不是添加在原来的 curl -s http://ip.cn 后面。而 -i 根本不是命令，所以自然找不到。

那么如果我们希望加入 -i 这参数，我们就必须重新完整的输入这个命令：
`docker run myip curl -s http://ip.cn -i`

ENTRYPOINT 版的查IP
```shell
FROM centos
RUN yum install -y curl
ENTRYPOINT [ "curl", "-s", "http://ip.cn" ]
```
![mark](http://7niu.chensr.cn/blog/20190620/UhO2CMXsYPId.png?imageslim)


#### 自定义镜像 tomcat
`mkdir -p /zzyyuse/mydockerfile/tomcat9`👇
在这个目录下创建 touch.txt👇
将jdk和tomcat安装的压缩包拷贝进上一步目录👇
在/zzyyuse/mydockerfile/tomcat9目录下新建Dockerfile文件👇
```shell
FROM centos
MAINTAINER    zzyy<zzyybs@126.com>
#把宿主机当前上下文的c.txt拷贝到容器/usr/local/路径下
COPY c.txt /usr/local/cincontainer.txt
#把java与tomcat添加到容器中
ADD jdk-8u171-linux-x64.tar.gz /usr/local/
ADD apache-tomcat-9.0.8.tar.gz /usr/local/
#安装vim编辑器
RUN yum -y install vim
#设置工作访问时候的WORKDIR路径，登录落脚点
ENV MYPATH /usr/local
WORKDIR $MYPATH
#配置java与tomcat环境变量
ENV JAVA_HOME /usr/local/jdk1.8.0_171
ENV CLASSPATH $JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar
ENV CATALINA_HOME /usr/local/apache-tomcat-9.0.8
ENV CATALINA_BASE /usr/local/apache-tomcat-9.0.8
ENV PATH $PATH:$JAVA_HOME/bin:$CATALINA_HOME/lib:$CATALINA_HOME/bin
#容器运行时监听的端口
EXPOSE  8080
#启动时运行tomcat
# ENTRYPOINT ["/usr/local/apache-tomcat-9.0.8/bin/startup.sh" ]
# CMD ["/usr/local/apache-tomcat-9.0.8/bin/catalina.sh","run"]
CMD /usr/local/apache-tomcat-9.0.8/bin/startup.sh && tail -F /usr/local/apache-tomcat-9.0.8/bin/logs/catalina.out
 
```
接着就是构建和 run 并验证
![mark](http://7niu.chensr.cn/blog/20190620/QChvUKFMpDlW.png?imageslim)

### 本地镜像发布到阿里云
[阿里云帮助文档](https://help.aliyun.com/product/60716.html)


