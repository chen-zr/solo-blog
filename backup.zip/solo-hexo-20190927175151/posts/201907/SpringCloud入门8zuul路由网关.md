title: Spring Cloud入门（8）- zuul 路由网关
date: '2019-07-10 22:28:19'
updated: '2019-07-10 22:46:32'
tags: [微服务, SC, SpringCloud, SOA]
permalink: /articles/2019/07/10/1562768899858.html
---
![](http://7niu.chensr.cn/blog/20190709/vHyRIOCTIhaj.png?imageslim)

### 概述
Zuul 包含了对请求的**路由**和**过滤**两个最主要的功能：

- 路由功能负责将外部请求转发到具体的微服务实例上，是实现外部访问统一入口的基础
- 过滤器功能则负责对请求的处理过程进行干预，是实现请求校验、服务聚合等功能的基础.

Zuul 和 Eureka 进行整合，将 Zuul 自身注册为 Eureka 服务治理下的应用，同时从 Eureka 中获得其他微服务的消息，也即以后的访问微服务都是通过 Zuul 跳转后获得。

### 路由基本配置
#### 直接撸代码
新建 Module 模块 microservicecloud-zuul-gateway-9527，修改 pom
```xml
<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-starter-eureka</artifactId>
</dependency>
<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-starter-zuul</artifactId>
</dependency>
```
yml 配置
```yml
server: 
  port: 9527
 
spring: 
  application:
    name: microservicecloud-zuul-gateway
 
eureka: 
  client: 
    service-url: 
      defaultZone: http://eureka7001.com:7001/eureka,http://eureka7002.com:7002/eureka,http://eureka7003.com:7003/eureka  
  instance:
    instance-id: gateway-9527.com
    prefer-ip-address: true 

info:
  app.name: atguigu-microcloud
  company.name: www.atguigu.com
  build.artifactId: $project.artifactId$
  build.version: $project.version$
```
主启动类加注解 @EnableZuulProxy，启动。
测试，不使用路由访问：http://localhost:8001/dept/get/2 ，使用路由访问 http://myzuul.com:9527/microservicecloud-dept/dept/get/2

### 路由访问映射规则
添加代理，修改 yml
```yml
zuul: 
  routes: 
    mydept.serviceId: microservicecloud-dept
    mydept.path: /mydept/**
```
修改之前访问地址是：
http://myzuul.com:9527/microservicecloud-dept/dept/get/2
修改之后访问地址是：
http://myzuul.com:9527/mydept/dept/get/1

此时，使用原路径和修改后的访问地址访问服务都是 ok 的。这时，我们需要将原地址忽略，修改 yml
```yml
zuul: 
  ignored-services: microservicecloud-dept 
  # 单个是具体的，多个是 *
  ignored-services: "*"
  routes: 
    mydept.serviceId: microservicecloud-dept
    mydept.path: /mydept/**
```
还可以设置统一的前缀：
```yml
zuul: 
  prefix: /atguigu
  ignored-services: "*"
  routes: 
    mydept.serviceId: microservicecloud-dept
    mydept.path: /mydept/**
```

此时，访问地址变成了：http://myzuul.com:9527/atguigu/mydept/dept/get/1
