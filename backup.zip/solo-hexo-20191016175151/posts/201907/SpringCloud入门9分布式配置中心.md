title: Spring Cloud入门（9）- 分布式配置中心
date: '2019-07-10 22:48:29'
updated: '2019-07-11 21:02:30'
tags: [微服务, SC, SpringCloud, SOA]
permalink: /articles/2019/07/10/1562770109913.html
---
![](http://7niu.chensr.cn/blog/20190709/vHyRIOCTIhaj.png?imageslim)

### 概述
#### 提出问题
微服务意味着要将单体应用中的业务拆分成一个个子服务，每个服务的粒度相对较小，因此系统中会出现大量的服务。由于每个服务都需要必要的配置信息才能运行，所以一套集中式的、动态的配置管理设施是必不可少的。SpringCloud 提供了 ConfigServer 来解决这个问题，我们每一个微服务自己带着一个application.yml，怎样管理这么多配置文件呢？

#### SpringCloud Config 是什么
SpringCloud Config 为微服务架构中的微服务提供集中化的外部配置支持，配置服务器为各个不同微服务应用的所有环境提供了一个中心化的外部配置。

#### 能干嘛
- 集中管理配置文件
- 不同环境不同配置，动态化的配置更新，分环境部署比如dev/test/prod/beta/release
- 运行期间动态调整配置，不再需要在每个服务部署的机器上编写配置文件，服务会向配置中心统一拉取配置自己的信息
- 当配置发生变动时，服务不需要重启即可感知到配置的变化并应用新的配置
- 将配置信息以REST接口的形式暴露

#### 与 Github 整合
由于 SpringCloud Config 默认使用 Git 来存储配置文件(也有其它方式,比如支持 SVN 和本地文件)，
但最推荐的还是 Git，而且使用的是 http/https 访问的形式。

###  SpringCloud Config 服务端配置
用自己的 GitHub 账号在 GitHub 上新建一个名为 microservicecloud-config 的新 Repository

由上一步获得 SSH 协议的 git 地址：git@github.com:zzyybs/microservicecloud-config.git

本地硬盘目录上新建 git 仓库并 clone：git clone git@github.com:zzyybs/microservicecloud-config.git

在克隆下的目录里新建一个 application.yml （D:\44\mySpringCloud\microservicecloud-config）

yml 内容：
```yml
spring:
  profiles:
    active:
    - dev
---
spring:
  profiles: dev     #开发环境
  application: 
    name: microservicecloud-config-atguigu-dev
---
spring:
  profiles: test   #测试环境
  application: 
    name: microservicecloud-config-atguigu-test
#  请保存为UTF-8格式
```
git add --> git commit -m "init yml" --> git push origin master 然后在 Github 上查看自己刚刚推送的文件

新建 Module 模块 microservicecloud-config-3344 它即为 Cloud 的配置中心模块

新模块的 pom 为：
```xml
<dependency>
     <groupId>org.springframework.cloud</groupId>
     <artifactId>spring-cloud-config-server</artifactId>
</dependency>
 ```

yml 配置文件为：
```yml
server: 
  port: 3344 
spring:
  application:
    name:  microservicecloud-config
  cloud:
    config:
      server:
        git:
          uri: git@github.com:zzyybs/microservicecloud-config.git #GitHub上面的git仓库名字
```
主启动类 Config_3344_StartSpringCloudApp 加注解 @EnableConfigServer

hosts 增加域名映射（127.0.0.1  config-3344.com）

测试通过 Config 微服务是否可以从 GitHub 上获取配置内容

#### 配置读取规则
- /{application}-{profile}.yml
	- http://config-3344.com:3344/application-dev.yml
	- http://config-3344.com:3344/application-test.yml
	- http://config-3344.com:3344/application-xxx.yml(不存在的配置)
- /{application}/{profile}[/{label}]
	- http://config-3344.com:3344/application/dev/master
	- http://config-3344.com:3344/application/test/master
	- http://config-3344.com:3344/application/xxx/master
- /{label}/{application}-{profile}.yml
	- http://config-3344.com:3344/master/application-dev.yml
	- http://config-3344.com:3344/master/application-test.yml


### SpringCloud Config客户端配置与测试
在本地 D:\44\mySpringCloud\microservicecloud-config 路径下新建文件 microservicecloud-config-client.yml，内容如下：
```yml
spring:
  profiles:
    active:
    - dev
---
server: 
  port: 8201 
spring:
  profiles: dev
  application: 
    name: microservicecloud-config-client
eureka: 
  client: 
    service-url: 
      defaultZone: http://eureka-dev.com:7001/eureka/   
---
server: 
  port: 8202 
spring:
  profiles: test
  application: 
    name: microservicecloud-config-client
eureka: 
  client: 
    service-url: 
      defaultZone: http://eureka-test.com:7001/eureka/
 
```
add --> commit -->push

新建 microservicecloud-config-client-3355 pom 与 3344 新增如下：
```xml
<!-- SpringCloud Config客户端 -->
<dependency>
     <groupId>org.springframework.cloud</groupId>
     <artifactId>spring-cloud-starter-config</artifactId>
</dependency> 
```
#### bootstrap.yml 是什么，applicaiton.yml 是用户级的资源配置项，bootstrap.yml 是系统级的，优先级更加高。
Spring Cloud 会创建一个`Bootstrap Context`，作为 Spring 应用的`Application Context`的父上下文。初始化的时候，`Bootstrap Context`负责从外部源加载配置属性并解析配置。这两个上下文共享一个从外部获取的`Environment`。`Bootstrap`属性有高优先级，默认情况下，它们不会被本地配置覆盖。 `Bootstrap context`和`Application Context`有着不同的约定，

所以新增了一个`bootstrap.yml`文件，保证`Bootstrap Context`和`Application Context`配置的分离。
```yml
spring:
  cloud:
    config:
      name: microservicecloud-config-client #需要从github上读取的资源名称，注意没有yml后缀名
      profile: dev   #本次访问的配置项
      label: master   
      uri: http://config-3344.com:3344  #本微服务启动后先去找3344号服务，通过SpringCloudConfig获取GitHub的服务地址
```

application.yml 文件内容
```yml
spring:
  application:
    name: microservicecloud-config-client
```
修改 hosts 文件，增加映射，127.0.0.1  client-config.com
新建 rest 类，验证是否能从 GitHub 上读取配置
```java
package com.atguigu.springcloud.rest;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
 
@RestController
public class ConfigClientRest {
  @Value("${spring.application.name}")
  private String applicationName;
  
  @Value("${eureka.client.service-url.defaultZone}")
  private String eurekaServers;
  
  @Value("${server.port}")
  private String port;
  
  @RequestMapping("/config")
  public String getConfig() {
    String str = "applicationName: "+applicationName+"\t eurekaServers:"+eurekaServers+"\t port: "+port;
    System.out.println("******str: "+ str);
    return "applicationName: "+applicationName+"\t eurekaServers:"+eurekaServers+"\t port: "+port;
  }
}
```

测试：
启动 Config 配置中心3344微服务并自测，http://config-3344.com:3344/application-dev.yml

启动 3355 作为Client准备访问，bootstrap.yml 里面的 profile 值是什么，决定从 github 上读取什么

- 假如目前是 profile: dev，dev默认在github上对应的端口就是8201，http://client-config.com:8201/config
- 假如目前是 profile: test，test默认在github上对应的端口就是8202

### SpringCloud Config配置实战
总结一下上面两步骤：

- Config 服务端配置配置 OK 且测试通过，我们可以和 config+GitHub 进行配置修改并获得内容
- 此时我们做一个 eureka 服务+一个 Dept 访问的微服务，将两个微服务的配置统一由于 github 获得实现统一配置分布式管理，完成多环境的变更。

#### Git配置文件本地配置
在本地 D:\44\mySpringCloud\microservicecloud-config 路径下分别新建各个模块的配置文件

- microservicecloud-config-eureka-client.yml
	```yml
	spring: 
	  profiles: 

	    active: 
	    - dev
	---
	server: 
	  port: 7001 #注册中心占用7001端口,冒号后面必须要有空格
	   
	spring: 
	  profiles: dev
	  application:
	    name: microservicecloud-config-eureka-client
	    
	eureka: 
	  instance: 
	    hostname: eureka7001.com #冒号后面必须要有空格
	  client: 
	    register-with-eureka: false #当前的eureka-server自己不注册进服务列表中
	    fetch-registry: false #不通过eureka获取注册信息
	    service-url: 
	      defaultZone: http://eureka7001.com:7001/eureka/
	---
	server: 
	  port: 7001 #注册中心占用7001端口,冒号后面必须要有空格
	   
	spring: 
	  profiles: test
	  application:
	    name: microservicecloud-config-eureka-client
	    
	eureka: 
	  instance: 
	    hostname: eureka7001.com #冒号后面必须要有空格
	  client: 
	    register-with-eureka: false #当前的eureka-server自己不注册进服务列表中
	    fetch-registry: false #不通过eureka获取注册信息
	    service-url: 
	      defaultZone: http://eureka7001.com:7001/eureka/
	```
- microservicecloud-config-dept-client.yml
	```yml
	spring: 
	  profiles:

	    active:
	    - dev
	--- 
	server:
	  port: 8001
	spring: 
	   profiles: dev
	   application: 
	    name: microservicecloud-config-dept-client
	   datasource:
	    type: com.alibaba.druid.pool.DruidDataSource
	    driver-class-name: org.gjt.mm.mysql.Driver
	    url: jdbc:mysql://localhost:3306/cloudDB01
	    username: root
	    password: 123456
	    dbcp2:
	      min-idle: 5
	      initial-size: 5
	      max-total: 5
	      max-wait-millis: 200 
	mybatis:
	  config-location: classpath:mybatis/mybatis.cfg.xml
	  type-aliases-package: com.atguigu.springcloud.entities
	  mapper-locations:
	  - classpath:mybatis/mapper/**/*.xml
	 
	eureka: 
	  client: #客户端注册进eureka服务列表内
	    service-url: 
	      defaultZone: http://eureka7001.com:7001/eureka
	  instance:
	    instance-id: dept-8001.com
	    prefer-ip-address: true
	 
	info:
	  app.name: atguigu-microservicecloud-springcloudconfig01
	  company.name: www.atguigu.com
	  build.artifactId: $project.artifactId$
	  build.version: $project.version$
	---
	server:
	  port: 8001
	spring: 
	   profiles: test
	   application: 
	    name: microservicecloud-config-dept-client
	   datasource:
	    type: com.alibaba.druid.pool.DruidDataSource
	    driver-class-name: org.gjt.mm.mysql.Driver
	    url: jdbc:mysql://localhost:3306/cloudDB02
	    username: root
	    password: 123456
	    dbcp2:
	      min-idle: 5
	      initial-size: 5
	      max-total: 5
	      max-wait-millis: 200  
	mybatis:
	  config-location: classpath:mybatis/mybatis.cfg.xml
	  type-aliases-package: com.atguigu.springcloud.entities
	  mapper-locations:
	  - classpath:mybatis/mapper/**/*.xml
	 
	eureka: 
	  client: #客户端注册进eureka服务列表内
	    service-url: 
	      defaultZone: http://eureka7001.com:7001/eureka
	  instance:
	    instance-id: dept-8001.com
	    prefer-ip-address: true
	 
	info:
	  app.name: atguigu-microservicecloud-springcloudconfig02
	  company.name: www.atguigu.com
	  build.artifactId: $project.artifactId$
	  build.version: $project.version$
	```

#### Config版的eureka服务端
新建工程 microservicecloud-config-eureka-client-7001，pom 如下：
```xml
<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
  xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
  <modelVersion>4.0.0</modelVersion>
  
  <parent>
    <groupId>com.atguigu.springcloud</groupId>
    <artifactId>microservicecloud</artifactId>
    <version>0.0.1-SNAPSHOT</version>
  </parent>
  
  <artifactId>microservicecloud-config-eureka-client-7001</artifactId>

  <dependencies>
    <!-- SpringCloudConfig配置 -->
    <dependency>
     <groupId>org.springframework.cloud</groupId>
     <artifactId>spring-cloud-starter-config</artifactId>
    </dependency> 
    <dependency>
     <groupId>org.springframework.cloud</groupId>
     <artifactId>spring-cloud-starter-eureka-server</artifactId>
    </dependency>
    <!-- 热部署插件 -->
    <dependency>
     <groupId>org.springframework</groupId>
     <artifactId>springloaded</artifactId>
    </dependency>
    <dependency>
     <groupId>org.springframework.boot</groupId>
     <artifactId>spring-boot-devtools</artifactId>
    </dependency>   
  </dependencies>
</project>
```
bootstrap.yml 配置如下：
```yml
spring: 
  cloud: 
    config: 
      name: microservicecloud-config-eureka-client     #需要从github上读取的资源名称，注意没有yml后缀名
      profile: dev 
      label: master 
      uri: http://config-3344.com:3344      #SpringCloudConfig获取的服务地址
```

application.yml 配置如下：
```yml
spring:
  application:
    name: microservicecloud-config-eureka-client
```

主启动类：
```java
package com.atguigu.springcloud;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;
 
/**
 * EurekaServer服务器端启动类,接受其它微服务注册进来
 * @author zhouyang
 */
@SpringBootApplication 
@EnableEurekaServer 
public class Config_Git_EurekaServerApplication {
  public static void main(String[] args)  {
    SpringApplication.run(Config_Git_EurekaServerApplication.class, args);
  }
}
```

测试，先启动 microservicecloud-config-3344 微服务，保证 Config 总配置是OK的，再启动 microservicecloud-config-eureka-client-7001 微服务，http://eureka7001.com:7001/，出现eureak主页表示成功启动。

#### Config 版的 dept 微服务
参考之前的8001拷贝后新建工程 microservicecloud-config-dept-client-8001，bootstrap.yml 如下：
```yml
spring:
  cloud:
    config:
      name: microservicecloud-config-dept-client #需要从github上读取的资源名称，注意没有yml后缀名
      #profile配置是什么就取什么配置dev or test
      #profile: dev
      profile: test
      label: master
      uri: http://config-3344.com:3344  #SpringCloudConfig获取的服务地址
```

主启动类:
```java
package com.atguigu.springcloud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
 
@SpringBootApplication
@EnableEurekaClient //本服务启动后会自动注册进eureka服务中
@EnableDiscoveryClient //服务发现
public class DeptProvider8001_App {
  public static void main(String[] args) {
     SpringApplication.run(DeptProvider8001_App.class, args);
  }
}
```
测试，test配置默认访问，http://localhost:8001/dept/list，可以看到数据库配置是02，本地换配置成dev，http://localhost:8001/dept/list，可以看到数据库配置是01。

总结，Spring Cloud Config 没有做过多研究，因为有比其更好的替代品，SpringCloud Alibaba Nacos，集注册中心和服务发现于一体。之后会做更多研究。