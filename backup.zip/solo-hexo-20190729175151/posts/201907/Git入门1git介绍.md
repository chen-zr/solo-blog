title: Git 入门（1）- git介绍
date: '2019-07-11 21:10:51'
updated: '2019-07-15 14:14:23'
tags: [git, github, gitlab]
permalink: /articles/2019/07/11/1562850651306.html
---
![mark](http://7niu.chensr.cn/blog/20190711/kC1z7jq7omfl.png?imageslim)

### git 和 svn 区别
#### 分布式与集中式
- 最核心的区别就是Git是分布式的， SVN是集中式的。SVN必须有一个服务器版本库就放在一个中央服务器。所有开发人员都是与服务器进行交互的。Git不需要有中心服务器，我们每台电脑拥有的东西都是一样的。
- 去中心化的好处是
  - 操作处理速度快（git本地交互，svn必须联网）
  - 不依赖网络（没有网络也可以commit，联网处理冲突，git commit到本地非常快）
  - 安全性更高（git 分布式，svn仓库宕机则全部损失）
#### 分支优势
- SVN 中分支是一个完整的目录，git 创建分支，只是多了些索引文件，用来记录分支的变化和指针，并且 git 创建分支快速且容易。
- 分支还可以用来进行代码审查，各个成员请求将自己的分支合并到主分支上，如果代码不合格，可以拒绝合并，完善后重新提交。
 - 总来来说就是 git 分支廉价。
#### git工作流
工作流之后专门放一节说。

### git结构
借用尚硅谷的一张图

![mark](http://7niu.chensr.cn/blog/20190624/S8XK0h5OyDfV.png?imageslim)

### git本地库和远程库
#### 团队内部协作

![mark](http://7niu.chensr.cn/blog/20190624/yAY7MwYnwN7Y.png?imageslim)

#### 跨团队协作

![mark](http://7niu.chensr.cn/blog/20190624/CGutDiAO4hvd.png?imageslim)


