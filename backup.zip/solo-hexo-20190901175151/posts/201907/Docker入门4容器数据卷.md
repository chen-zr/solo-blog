title: Docker入门（4）- 容器数据卷
date: '2019-07-09 20:43:42'
updated: '2019-07-09 21:34:39'
tags: [docker, 容器]
permalink: /articles/2019/07/09/1562676222190.html
---
![](http://7niu.chensr.cn/blog/20190709/vjse48VX7QFq.png?imageslim)

#### 数据卷是什么
应用与环境打包形成容器并运行之后，容器内的数据会被保存吗？如果我们对数据要求是持久化的，或者希望可以在主机和容器之间共享数据怎么做呢？

Docker 容器中产生的数据，如果不通过 docker commit 生成新的镜像，使数据作为镜像的一部分保存下来，那么在删除容器的时候，数据也随之被删除了。

#### 数据卷能干嘛
卷就是一个文件或者一个目录，存在于一个或多个容器中，由 docker 挂载到容器中，但不属于镜像的联合文件系统，因此可以绕过 UFS 提供一些持续存储或共享数据的特性。

**卷的设计目标就是数据的持久化，完全独立于容器的生存周期，因此 docker 不会在删除容器时删除其挂载的卷。**

##### 数据卷的特点：
- 数据卷可以在容器之间共享或重用数据
- 卷中的更改可以直接生效
- 卷中的更改不会包含在镜像的更新中
- 卷的生命周期不依赖容器

`总的来说，卷的作用就是提供容器的持久化数据，便于容器间继承和共享数据。`

##### 命令
- `docker run -it -v /宿主机目录:/容器内目录 [centos /bin/bash]`
- `docker inspect 容器ID` 查看容器数据卷是否挂载成功

##### Dockerfile
Dcckerfile 中可以使用 VOLUME 命令给镜像添加一个或多个数据卷
```shell
# volume test
FROM centos
VOLUME ["/data1","/data2"]
CMD echo "finished,--------success1"
CMD /bin/bash
```
编写好之后开始根据 Dockerfile 文件生成镜像。
`docker build -f /mydocker/dockerfile2 -t mycentos .` 注意这里有个点！

之后运行容器，我们会发现容器对应的目录下，会有两个 data 文件夹，那么容器中的这两个文件夹对应宿主机内的哪个文件夹呢？

通过`docker inspect 容器ID`可以知道，挂载到了`/var/lib/docker/volumes/`下。

这个挂载映射关系是跟随容器的生命周期的，如果容器停止，挂载关系还会存在，重新启动容器后，挂载关系恢复。如果容器删除后，映射关系失效，但是宿主机上的文件夹还是会存在。

> Docker挂载主机目录Docker访问出现cannot open directory .: Permission denied
解决办法：在挂载目录后多加一个--privileged=true参数即可

#### 数据卷容器
命名的容器挂载数据卷，**其它容器通过挂载这个(父容器)实现数据共享**，挂载数据卷的容器，称之为数据卷容器。

##### 继承运行
根据上面生成的镜像 mycentos 为模板运行容器 test1，然后我们在 data1 下新增一个文件，之后再用 mycentos 模板运行容器 test2 test3，并且是继承运行。

命令：`docker run -it --name test2 --volumes-from test1 mycentos`
test2 和 test3 都使用这个命令运行新的容器。
然后分别在 test2 和 test3 的 data2 中都新增内容，回到 test1 中，可以看到 data2 中可以看到 test2 和 test3 新增的内容。即 test1 test2 test3 下 data1 和 data2 的文件夹是共享的。如果删除 test1 那么 test2 和 test3 也是会共享的。

结论：**容器之间配置信息的传递，数据卷的生命周期一直持续到没有容器使用它为止**。