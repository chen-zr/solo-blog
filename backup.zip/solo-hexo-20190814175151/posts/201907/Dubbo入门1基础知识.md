title: Dubbo入门（1）- 基础知识
date: '2019-07-11 21:58:35'
updated: '2019-07-11 21:59:12'
tags: [dubbo, 分布式, SOA, 微服务]
permalink: /articles/2019/07/11/1562853514986.html
---
![mark](http://7niu.chensr.cn/blog/20190711/qocemNSvH9ov.png?imageslim)

### 分布式基础理论
#### 概念
> 《分布式系统原理与范型》
分布式系统是若干独立计算机的集合，这些计算机对于用户来说就像单个相关系统。

随着互联网的发展，网站应用的规模不断扩大，常规的垂直应用架构已无法应对，分布式服务架构以及流动计算架构势在必行，亟需一个治理系统确保架构有条不紊的演进。

#### 发展演变
![mark](http://7niu.chensr.cn/blog/20190626/nINU48Icg2Ty.png?imageslim)

##### 单一架构
此类应用往往流量小，几乎没有并发，只用一个应用将所有功能部署在一起，减少部署节点和成本。

特点：适用于小型网站，小型管理系统，简单易用。
缺点：性能扩展难，协同开发难，不利于升级维护。
![mark](http://7niu.chensr.cn/blog/20190701/7Mt8mlrYoGEE.png?imageslim)

##### 垂直应用架构
当访问量增大，单一应用带来的加速度小，此时，将应用拆分成几个不相干的应用，提升效率。

特点：通过切分业务实现各个模块独立部署，降低维护和部署难度，并且开发各司其职，性能扩展方便。
缺点：公用模块无法复用，浪费部分开发。
![mark](http://7niu.chensr.cn/blog/20190701/HqwCSjOqH2AT.png?imageslim)

##### 分布式服务架构
垂直应用越来越多，应用之间不可避免的交互，因此将核心业务抽离出来，作为独立的服务，逐渐形成稳定的服务中心，使前端应用能更好的响应多变的市场（前后端分离），这时，用于提高业务复用及整合的分布式服务框架是关键。

比如：企业总线（bus）、负载均衡硬件
![mark](http://7niu.chensr.cn/blog/20190701/UHhSMAEhLOFp.png?imageslim)

##### 流动计算架构
当服务越来越多，容量的评估，小服务资源的浪费等问题接踵而至，这时，就急需一个调度中心实时管理集群容量，提高集群的利用率。因此，用于提高机器利用率的资源调度系统和治理中心（SOA，Service Oriented Architecture）是关键。

![mark](http://7niu.chensr.cn/blog/20190701/URgA86WvekST.png?imageslim)

#### 什么是RPC？
RPC（Remote Proceduce Call）远程过程调用，是一种进程间的通信方式，是一种技术思想，而不是规范。它允许程序调用另外一个地址空间的（通常是另外一台服务器或容器上的）过程或函数，而不用程序员显示编码这个调用的细节。即程序员无论是调用本地还是远程的函数，本质上编写的调用代码基本相同。
![mark](http://7niu.chensr.cn/blog/20190701/BuSik0vMWJb8.png?imageslim)

![mark](http://7niu.chensr.cn/blog/20190701/pqAdlXQKDOpz.png?imageslim)

从上图中我们可以看出，RPC的核心模块：序列化、通讯。