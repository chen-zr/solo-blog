title: Git 入门（3）- Git 工作流
date: '2019-07-22 13:41:28'
updated: '2019-07-22 13:41:28'
tags: [git, gitlab, github]
permalink: /articles/2019/07/22/1563774088201.html
---
![mark](http://7niu.chensr.cn/blog/20190711/kC1z7jq7omfl.png?imageslim)

###集中式工作流
像 svn 一样，以中央仓库作为项目所有修改的单点实体。所有修改都提交到 Master 这个分支上。
![mark](http://7niu.chensr.cn/blog/20190722/z8fad2Jj3VyE.png?imageslim)

### GitFlow 工作流
通过为功能开发、发布准备和维护设立了独立的分支，让发布迭代过程更流畅。严格的分支模型也为大型项目提供了一些非常必要的结构。
![mark](http://7niu.chensr.cn/blog/20190722/DTIVD8Kt8GhD.png?imageslim)

### Forking 工作流
Forking 工作流是在 GitFlow 基础上，充分利用了 Git 的 Fork 和 pull request 的功能以达到代码审核的目的。更适合安全可靠地管理大团队的开发者，而且能接受不信任贡献者的提交。

![mark](http://7niu.chensr.cn/blog/20190722/CReN3sqrOOX8.png?imageslim)

### 分支种类
#### master 主干分支
主要负责管理正在运行的生产环境代码。永远保持与正在运行的生产环境完全一致。

#### 开发分支 develop
负责管理正在开发过程中的代码，一般情况下是最新的代码。

#### 准生产分支 release
较大的版本上线前，会从开发分支分出准生产分支，进行最后的集成测试，版本上线后，会合并到主干分支。生产环境运行一段时间稳定后，可以删除。

#### 功能分支 feature
为了不影响短周期的开发工作，一般把中长期开发模块，从开发分支中独立出来，开发完成后合并到开发分支。

![mark](http://7niu.chensr.cn/blog/20190722/7OT628JkrOvM.png?imageslim)

