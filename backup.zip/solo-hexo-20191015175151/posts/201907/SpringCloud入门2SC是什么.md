title: Spring Cloud入门（2）- SC是什么
date: '2019-07-09 20:51:01'
updated: '2019-07-09 21:35:51'
tags: [微服务, SC, SpringCloud, SOA]
permalink: /articles/2019/07/09/1562676661578.html
---
![](http://7niu.chensr.cn/blog/20190709/vHyRIOCTIhaj.png?imageslim)

### 是什么
#### 是什么？
SpringCloud，基于SpringBoot提供了一套微服务解决方案，包括服务注册与发现，配置中心，全链路监控，服务网关，负载均衡，熔断器等组件，除了基于NetFlix的开源组件做高度抽象封装之外，还有一些选型中立的开源组件。
 
SpringCloud利用SpringBoot的开发便利性巧妙地简化了分布式系统基础设施的开发，SpringCloud为开发人员提供了快速构建分布式系统的一些工具，**包括配置管理、服务发现、断路器、路由、微代理、事件总线、全局锁、决策竞选、分布式会话等等**，它们都可以用SpringBoot的开发风格做到一键启动和部署。

#### 和 Dubbo 比？
![mark](http://7niu.chensr.cn/blog/20190705/Ekit40OeFUbs.png?imageslim)
![mark](http://7niu.chensr.cn/blog/20190705/s3jJiwxiQcnq.png?imageslim)

最大区别：SpringCloud抛弃了Dubbo的RPC通信，采用的是基于HTTP的REST方式。

严格来说，这两种方式各有优劣。虽然从一定程度上来说，后者牺牲了服务调用的性能，但也避免了上面提到的原生RPC带来的问题。而且REST相比RPC更为灵活，服务提供方和调用方的依赖只依靠一纸契约，不存在代码级别的强依赖，这在强调快速演化的微服务环境下，显得更加合适。

SC 就像品牌机，而 Dubbo 更像组装机，而且 SC 还可以和 Spring 生态圈内其他项目融合，这对于微服务来说是相当重要的。并且 SC 的社区力量也比 Dubbo 要强大，要活跃。

就像 Dubbo 前负责人刘军说的，Dubbo 的定位始终是一款 RPC 框架，而 SC 目的是微服务架构下的一站式解决方案。

### 能干嘛
- 分布式配置中心/版本控制（SpringCloud Config）
- 服务注册与发现（Eureka）
- 路由和网关（Zuul）
- 服务间调用（gRPC）
- 负载均衡（Ribbon + Feign）
- 断路器（Hystrix）
- ......

### 国内使用情况
![mark](http://7niu.chensr.cn/blog/20190705/I8dfboe1sAhA.png?imageslim)


