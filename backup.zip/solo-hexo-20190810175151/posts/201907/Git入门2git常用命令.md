title: Git 入门（2）- git 常用命令
date: '2019-07-11 21:12:14'
updated: '2019-07-22 13:23:09'
tags: [git, gitlab, github]
permalink: /articles/2019/07/11/1562850734823.html
---
![mark](http://7niu.chensr.cn/blog/20190711/kC1z7jq7omfl.png?imageslim)

## git 命令
### 基础命令
#### 本地仓库初始化
`git init` 初始化当前文件夹，将当前文件夹加入版本控制，并生成.git文件夹。
#### 设置签名
用来区分不同开发人员的身份（与登陆远程仓库的用户账密无关）
##### 项目级别
`git config user.name chensr`
`git config user.email czpanda16@gmail.com`

保存在 `./.git/config` 文件中
##### 系统用户级别
`git config --global user.name chensr`
`git config --global czpanda16@gmail.com`

保存在 `~/.gitconfig` 文件中

#### 基本操作
##### 状态查看
`git status` 查看工作区、缓存区状态

##### 添加
`git add [filename]` 将工作区的“新建、修改”添加到暂存区

##### 提交
`git commit -m "commit message" [filename]` 将暂存区的内容提交到本地库

##### 查看历史记录
`git log` 详细历史记录
`git log --pretty=oneline` 每个变动用一行显示
`git log --oneline` 每个变动ID简写
`git reflog` 显示指针 HEAD 移动需要几步

##### 前进后退
`git reset --hard [局部索引值]` 基于索引值操作
`git reset --soft [局部索引值]` 仅仅在本地库移动指针
`git reset --mixed [局部索引值]` 本地库移动且重置暂存区
`git reset --hard [局部索引值]` 本地库移动且重置暂存区和工作区

##### 删除文件并找回
前提：删除前文件已经提到了本地版本库
`git reset --hard [指针位置]`

##### 比较文件差异
`git diff 文件名` 工作区和暂存区比较
`git diff [本地库版本] [文件名]` 工作区与本地库比较

#### 分支
![mark](http://7niu.chensr.cn/blog/20190625/LqBzrpiXDbgx.png?imageslim)
##### 分支好处
- 同时并行推进多个功能开发，提高开发效率
- 各个分支在开发过程中，如果一个分支开发失败，不会对其他分支有任何影响

##### 分支命令
`git branch [分支名]` 创建分支
`git branch -v ` 查看分支
`git checkout [分支名]` 切换分支

合并分支：
- 切换到接受修改的分支（被合并）`git checkou [被合并分支名]`
- merge `git merge [要合并的分支名]`

解决冲突：
- 编辑文件，删除特殊的符号（一般是冲突位置）
- 修改，保存
- add commit（这个commit不带文件名）

### 基本原理
#### 哈希
哈希是一个系列的加密算法，不同的哈希算法加密强度不同，但是有以下几个共同点：

- 不管输入数据的数据量有多大，输入同一个哈希算法，得到的加密结果长度相同；
- 哈希算法确定，输入数据确定，输出数据能够保持不变；
- 哈希算法确定，输入数据有变化，输出数据通常有变化，且变化很大；
- 哈希算法不可逆

Git 底层采用的是 SHA-1 算法。

哈希算法可以用来验证文件，原理如图所示：
![mark](http://7niu.chensr.cn/blog/20190722/VLUpANSsJmuC.png?imageslim)

#### Git 保存版本机制
##### 集中式版本控制工具的文件管理机制
以文件变更列表的方式存储信息。这类系统将它们保存的信息看作是一组基本文件和每个文件随时间逐步累积的差异。
![mark](http://7niu.chensr.cn/blog/20190722/XOkNLG2ocGvh.png?imageslim)

##### Git 文件管理机制
Git 把数据看作是小型文件系统的一组快照。每次提交更新时 Git 都会对当前的全部文件制作一个快照并保存这个快照的索引。为了高效，如果文件没有修改，Git 不再重新存储该文件，而是只保留一个链接指向之前存储的文件。所以 Git 的工作方式可以称之为快照流。
![mark](http://7niu.chensr.cn/blog/20190722/rA3ljqvTmkJA.png?imageslim)

