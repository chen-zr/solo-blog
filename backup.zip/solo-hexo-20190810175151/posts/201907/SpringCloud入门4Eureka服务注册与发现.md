title: Spring Cloud入门（4）- Eureka服务注册与发现
date: '2019-07-09 21:37:00'
updated: '2019-07-09 21:38:12'
tags: [微服务, SC, SpringCloud, SOA]
permalink: /articles/2019/07/09/1562679420647.html
---
![](http://7niu.chensr.cn/blog/20190709/vHyRIOCTIhaj.png?imageslim)

### Eureka 是什么
Eureka 是 Netflix 的一个子模块，也是核心模块之一。Eureka 是一个基于REST的服务，**用于定位服务、服务注册与发现**。有了服务发现与注册，只需要使用服务的标识符，就可以访问到服务，而不需要修改服务调用的配置文件了。功能类似于 dubbo 的注册中心，比如 Zookeeper。

Eureka 遵守的是 AP 原则，而 Zookeeper 遵守的是 CP 原则。
CAP：Consistency（一致性）、 Availability（可用性）、Partition tolerance（分区容错性）

### 原理
#### 基本架构
Eureka 采用了 C-S 的设计架构。Eureka Server 作为服务注册功能的服务器，它是服务注册中心。

而系统中的其他微服务，使用 Eureka 的客户端连接到 Eureka Server并维持心跳连接。这样系统的维护人员就可以通过 Eureka Server 来监控系统中各个微服务是否正常运行。

SpringCloud 的一些其他模块（比如Zuul）可以通过 Eureka Server 来发现系统中的其他微服务，并执行相关的逻辑。

![mark](http://7niu.chensr.cn/blog/20190705/RCSbK0pgq1Lv.png?imageslim)

对比 Dubbo 的 Zookeeper
![mark](http://7niu.chensr.cn/blog/20190705/EGGLRiKn5ghB.png?imageslim)

#### Eureka 三种角色
- Eureka Server 提供服务注册和发现
- Service Provider服务提供方将自身服务注册到Eureka，从而使服务消费方能够找到
- Service Consumer服务消费方从Eureka获取注册服务列表，从而能够消费服务

#### 盘点上一节我们工程的目录情况
- 总工程（父工程）
- 通用模块 API
- 服务提供者 Provider
- 服务消费者 Consumer

### 改造现有工程
#### microservicecloud-eureka-7001 eureka 服务注册中心 Module
新建microservicecloud-eureka-7001
pom 如下：
```xml
<parent>
    <groupId>com.atguigu.springcloud</groupId>
    <artifactId>microservicecloud</artifactId>
    <version>0.0.1-SNAPSHOT</version>
</parent>
 
<artifactId>microservicecloud-eureka-7001</artifactId>
 
<dependencies>
    <!--eureka-server服务端 -->
    <dependency>
        <groupId>org.springframework.cloud</groupId>
        <artifactId>spring-cloud-starter-eureka-server</artifactId>
    </dependency>
<dependencies>
```
yml 配置文件
```yml
server: 
  port: 7001
 
eureka:
  instance:
    hostname: localhost #eureka服务端的实例名称
  client:
    register-with-eureka: false #false表示不向注册中心注册自己。
    fetch-registry: false #false表示自己端就是注册中心，我的职责就是维护服务实例，并不需要去检索服务
    service-url:
      defaultZone: http://${eureka.instance.hostname}:${server.port}/eureka/        #设置与Eureka Server交互的地址查询服务和注册服务都需要依赖这个地址。
```
EurekaServer7001_App主启动类
```java
package com.atguigu.springcloud;
 
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;
 
@SpringBootApplication
//EurekaServer服务器端启动类,接受其它微服务注册进来
@EnableEurekaServer
public class EurekaServer7001_App {
  public static void main(String[] args) {
    SpringApplication.run(EurekaServer7001_App.class, args);
  }
}
```
测试 Eureka Server 是否启动成功
![mark](http://7niu.chensr.cn/blog/20190705/ChF92af98lyh.png?imageslim)

No application available 没有服务被发现，因为没有注册服务进来当然不可能有服务被发现

#### microservicecloud-provider-dept-8001 将已有的部门微服务注册进eureka服务中心
pom：
```xml
<!-- 将微服务provider侧注册进eureka -->
<dependency>
  <groupId>org.springframework.cloud</groupId>
  <artifactId>spring-cloud-starter-eureka</artifactId>
</dependency>
<dependency>
  <groupId>org.springframework.cloud</groupId>
  <artifactId>spring-cloud-starter-config</artifactId>
</dependency>
```

yml 加入 Eureka 配置：
```yml
eureka:
  client: #客户端注册进eureka服务列表内
    service-url: 
      defaultZone: http://localhost:7001/eureka
```

DeptProvider8001_App主启动类
```java
package com.atguigu.springcloud;
 
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
 
@SpringBootApplication
@EnableEurekaClient //本服务启动后会自动注册进eureka服务中
public class DeptProvider8001_App {
  public static void main(String[] args) {
    SpringApplication.run(DeptProvider8001_App.class, args);
  }
}
```
测试：
先要启动 Eureka Server 端，然后再启动 provider

![mark](http://7niu.chensr.cn/blog/20190705/uEHd9LtBDAcC.png?imageslim)
yml 中更改应用名称：Spring:application:name

#### actuator 与注册微服务信息完善
##### 主机名称:服务名称修改
在 Eureka 注册中心中有两个名称：
- 一个是应用名称，需要修改 yml 中 spring:application:name 
- 一个是 Eureka 实例名称，需要修改 yml 中 eureka:instance:instance-id

![mark](http://7niu.chensr.cn/blog/20190705/iQp6Iu9in2wn.png?imageslim)

##### 访问信息有 IP 信息提示
再 Eureka 注册中心 web 端看到我们所起的服务时，发现只有服务名称，没有名称对应的服务的 IP 地址，此时我们需要在 yml 中设置显示 IP 地址。

yml 中加入配置：eureka:instance:prefer-ip-address:true

修改之后，当我们点击 status 时，会在 General info 显示出这个服务对应的 IP 地址。

##### 微服务 info 内容详细信息
当我们点击服务列表中的超链接时，会报 ErrorPage 的错误，这是因为没有配置微服务详情信息。

首先我们需要在 provider 的 pom 配置中，加入如下配置
```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-actuator</artifactId>
</dependency>
```
修改父工程的 pom 加入如下配置：
```xml
<build>
    <finalName>microservicecloud</finalName>
    <resources>
        <resource>
            <directory>src/main/resources</directory>
            <filtering>true</filtering>
        </resource>
    </resources>
    <plugins>
        <plugin>
            <groupId>org.apache.maven.plugins</groupId>
            <artifactId>maven-resources-plugin</artifactId>
            <configuration>
                <delimiters>
                    <delimit>$</delimit>
                </delimiters>
            </configuration>
        </plugin>
    </plugins>
</build>
```

在 provider 的 yml 配置文件中加入如下配置：
```yml
info:
  app.name: atguigu-microservicecloud
  company.name: www.atguigu.com
  build.artifactId: $project.artifactId$
  build.version: $project.version$
```

#### Eureka 的自我保护
默认情况下，如果 EurekaServer 在一定时间内没有接收到某个微服务实例的心跳，EurekaServer 将会注销该实例（默认90秒）。但是当网络分区故障发生时，微服务与 EurekaServer 之间无法正常通信，以上行为可能变得非常危险了——因为微服务本身其实是健康的，`此时本不应该注销这个微服务`。

Eureka 通过“自我保护模式”来解决这个问题——当 EurekaServer 节点在短时间内丢失过多客户端时（可能发生了网络分区故障），那么这个节点就会进入自我保护模式。一旦进入该模式，EurekaServer 就会保护服务注册表中的信息，不再删除服务注册表中的数据（也就是不会注销任何微服务）。当网络故障恢复后，该Eureka Server节点会自动退出自我保护模式。

在自我保护模式中，Eureka Server 会保护服务注册表中的信息，不再注销任何服务实例。当它收到的心跳数重新恢复到阈值以上时，该 Eureka Server 节点就会自动退出自我保护模式。它的设计哲学就是宁可保留错误的服务注册信息，也不盲目注销任何可能健康的服务实例。一句话讲解：好死不如赖活着。

eureka.server.enable-self-preservation = false 禁用自我保护模式

#### provider 服务发现 Discovery
对于注册到 Eureka 的服务，可以通过服务发现来获得该服务注册的信息
修改 DeptController.java 
```java
@RequestMapping(value = "/dept/discovery", method = RequestMethod.GET)
public Object discovery() {
    List<String> list = client.getServices();
    System.out.println("**********" + list);

    List<ServiceInstance> srvList = client.getInstances("MICROSERVICECLOUD-DEPT");
    for (ServiceInstance element : srvList) {
        System.out.println(element.getServiceId() + "\t" + element.getHost() + "\t" + element.getPort() + "\t"
        + element.getUri());
    }
    return this.client;
}
```

主启动类加上 @EnableDiscoveryClient 注解

先启动 Eureka server 再启动 provider，测试地址： http://localhost:8001/dept/discovery

修改 consumer 的 DepeController_consumer.java 在消费端测试可以调用服务发现
```java
//测试@EnableDiscoveryClient,消费端可以调用服务发现
@RequestMapping(value="/consumer/dept/discovery") 
public Object discovery() {
    return restTemplate.getForObject(REST_URL_PREFIX+"/dept/discovery", Object.class);
} 
```

### Eureka 集群配置
#### 原理
- 处于不同节点的eureka通过Replicate进行数据同步 
- Application Service 为服务提供者 
- Application Client 为服务消费者 
- Make Remote Call 完成一次服务调用

服务启动后向 Eureka 注册，Eureka Server 会将注册信息向其他 Eureka Server 进行同步，当服务消费者要调用服务提供者，则向服务注册中心获取服务提供者地址，然后会将服务提供者地址缓存在本地，下次再调用时，则直接从本地缓存中取，完成一次调用。
 
当服务注册中心 Eureka Server 检测到服务提供者因为宕机、网络原因不可用时，则在服务注册中心将服务置为 DOWN 状态，并把当前服务提供者状态向订阅者发布，订阅过的服务消费者更新本地缓存。

服务提供者在启动后，周期性（默认30秒）向 Eureka Server 发送心跳，以证明当前服务是可用状态。Eureka Server 在一定的时间（默认90秒）未收到客户端的心跳，则认为服务宕机，注销该实例。

##### 新建microservicecloud-eureka-7002/microservicecloud-eureka-7003（同7001）
配置文件如下
```yml
eureka: 
  instance:
    hostname: eureka7001.com #eureka服务端的实例名称
  client: 
    register-with-eureka: false     #false表示不向注册中心注册自己。
    fetch-registry: false     #false表示自己端就是注册中心，我的职责就是维护服务实例，并不需要去检索服务
    service-url: 
      #单机 defaultZone: http://${eureka.instance.hostname}:${server.port}/eureka/       #设置与Eureka Server交互的地址查询服务和注册服务都需要依赖这个地址（单机）。
      defaultZone: http://eureka7002.com:7002/eureka/,http://eureka7003.com:7003/eureka/
```

7002 7003 同 7001

provider 在注册服务时，需要像三台 eureka 服务器同时注册服务。

##### 作为服务注册中心，Eureka比Zookeeper好在哪里
一个分布式系统不可能同时满足C(一致性)、A(可用性)和P(分区容错性)。

Zookeeper 保证的是 CP，Eureka 则是 AP。

`Zookeeper 保证 CP`
当向注册中心查询服务列表时，我们可以容忍注册中心返回的是几分钟以前的注册信息，但不能接受服务直接down掉不可用。也就是说，服务注册功能对可用性的要求要高于一致性。但是zk会出现这样一种情况，当 master 节点因为网络故障与其他节点失去联系时，剩余节点会重新进行 leader 选举。问题在于，选举 leader 的时间太长，30 ~ 120s, 且选举期间整个 zk 集群都是不可用的，这就导致在选举期间注册服务瘫痪。

`Eureka 保证 AP`
Eureka 各个节点都是平等的，几个节点挂掉不会影响正常节点的工作，剩余的节点依然可以提供注册和查询服务。而 Eureka 的客户端在向某个 Eureka 注册或时如果发现连接失败，则会自动切换至其它节点，只要有一台 Eureka 还在，就能保证注册服务可用(保证可用性)，只不过查到的信息可能不是最新的(不保证强一致性)。

除此之外，Eureka 还有一种自我保护机制，如果在15分钟内超过85%的节点都没有正常的心跳，那么 Eureka 就认为客户端与注册中心出现了网络故障，此时会出现以下几种情况：
- Eureka不再从注册列表中移除因为长时间没收到心跳而应该过期的服务 
- Eureka仍然能够接受新服务的注册和查询请求，但是不会被同步到其它节点上(即保证当前节点依然可用)
- 当网络稳定时，当前实例新的注册信息会被同步到其它节点中



