title: Docker入门（2） - Docker 常用命令
date: '2019-07-09 20:35:36'
updated: '2019-07-09 21:34:13'
tags: [docker, 容器]
permalink: /articles/2019/07/09/1562675736192.html
---
![](http://7niu.chensr.cn/blog/20190709/vjse48VX7QFq.png?imageslim)

### 帮助命令
- `docker version`: 查询 Docker 版本 
- `docker info`: 查询当前 Docker 信息，包括容器运行信息，内核信息等。
- `docker --help`: 查询 Docker 帮助命令

### 镜像命令
- `docker images`: 列出本地主机上的镜像
  - ![mark](http://7niu.chensr.cn/blog/20190613/DNetB8kTPTIE.png?imageslim)
  - REPOSITORY：表示镜像的仓库源
  - TAG：镜像的标签
  - IMAGE ID：镜像ID
  - CREATED：镜像创建时间
  - SIZE：镜像大小
  - 同一个仓库源可以有多个TAG，代表仓库源的不同版本，默认name:latest
  - options 说明
    - -a 列出所有镜像 
    - -q 只显示镜像ID
    - --digests :显示镜像的摘要信息
    - --no-trunc :显示完整的镜像信息
- docker search xxx: 在dockers hub上搜索镜像
  - `docker search xxx [options]`
    - --no-trunc : 显示完整的镜像描述
    - -s : 列出收藏数不小于指定值的镜像。
    - --automated : 只列出 automated build类型的镜像
- dokcer pull xxx: 下载某个镜像
  - `docker pull xxx[:TAG]`
- docker rmi xxxid: 删除某个镜像（按镜像ID）
  - `docker rmi -f xxxid` 删除单个
  - `docker rmi -f 镜像名1:TAG 镜像名2:TAG`
  - `docker rmi -f $(docker images -qa)` 删除全部
  
### 容器命令
根本前提：有镜像才能有容器。

- 新建并启动容器
  - `docker run [options] image [command] [arg...]`
  - --name="容器新名字": 为容器指定一个名称
  - -d: 后台运行容器，并返回容器ID，也即启动守护式容器
  - -i：以交互模式运行容器，通常与 -t 同时使用；
  - -t：为容器重新分配一个伪输入终端，通常与 -i 同时使用
  - -P: 随机端口映射
  - -p: 指定端口映射，有以下四种格式
    - ip:hostPort:containerPort
    - ip::containerPort
    - hostPort:containerPort
    - containerPort
- 列出当前正在运行的容器
  - `docker ps [options]`
  - -a :列出当前所有正在运行的容器+历史上运行过的
  - -l :显示最近创建的容器
  - -n：显示最近n个创建的容器
  - -q :静默模式，只显示容器编号
  - --no-trunc :不截断输出
- 退出容器
  - exit 容器停止退出
  - ctrl+P+Q 容器不停止退出
- 启动容器
  - `docker start` 容器id或容器名`
  - `docker restart` 容器id或容器名
  - `docker stop` 容器id或容器名
  - `docker kill` 容器ID或容器名 强行停止
- 删除容器
  - `dokcer rm 容器ID` 删除已经停止的容器
  - `docker rm -f $(docker ps -a -q)` 一次删除多个容器
  - `docker ps -a -q | xargs docker rm` 一次删除多个容器
- **重要命令**
  - `docker run -d 容器名` 启动守护式容器
    - e.g. docker run -d centos
    - **Docker容器后台运行,就必须有一个前台进程**
    - 容器运行的命令如果不是那些一直挂起的命令（比如运行top，tail），就是会自动退出的
  - `docker logs -f -t --tail 10 容器ID` 查看容器日志
    - -t 是加入时间戳
    - -f 跟随最新的日志打印
    -  --tail 数字 显示最后多少条
  - `docker top 容器ID` 查看容器内运行的进程
  - `docker inspect 容器ID` 查看容器内部细节
  - `docker exec -it 容器ID /bin/bash` 进入正在运行的容器并以命令行交互
    - 重新进入 docker attach 容器ID
    - attach 直接进入容器启动命令的终端，不会启动新的进程
    - exec 是在容器中打开新的终端，并且可以启动新的进程
  - `docker cp 容器ID:容器内路径 目的主机路径` 从容器内拷贝文件到主机上


