title: Spring Cloud入门（1）- 概述
date: '2019-07-09 20:50:06'
updated: '2019-07-09 21:35:42'
tags: [微服务, SC, SpringCloud, SOA]
permalink: /articles/2019/07/09/1562676605783.html
---
![](http://7niu.chensr.cn/blog/20190709/vHyRIOCTIhaj.png?imageslim)

### 微服务是什么？
马丁.福勒（Martin Fowler）的[论文](https://martinfowler.com/articles/microservices.html)，点击直达。

目前来说，微服务还没有统一的、标准的定义（While there is no precise definition of this architectural style）。

通常而言，微服务架构是一种**架构模式**或者说是一种**架构风格**，它提倡将单一应用程序划分成一组小的服务，每个服务运行在其独立的自己的进程中，服务之间互相协调、互相配合，为用户提供最终价值。

服务之间采用轻量级的通信机制互相沟通（通常是基于HTTP的RESTful API 或 远程 RPC 调用）。每个服务都围绕着具体业务进行构建，并且能够被独立地部署到生产环境、类生产环境等。

**从技术层面通俗的理解呢？**
微服务化的核心就是将传统的一站式应用，++根据业务拆分成一个一个的服务，彻底地去耦合,每一个微服务提供单个业务功能的服务，一个服务做一件事，从技术角度看就是一种小而独立的处理过程++，类似进程概念，能够自行单独启动或销毁，拥有自己独立的数据库。

### 微服务和微服务架构？—— 傻傻分不清楚
微服务架构是⼀种架构模式，它提倡将单⼀应⽤程序划分成⼀组⼩的服务，服务之间互相协调、互相配合，为⽤户提供最终价值。

而微服务是整个应用中一个个微小的服务，每个服务都围绕着具体业务进⾏构建，并且能够被独⽴的部署到⽣产环境、类⽣产环境等。

### 微服务优点？缺点？—— 不是任何框架都是完美的
#### 优点
- 每个服务高内聚，低耦合，代码容易理解，这样能聚焦一个指定的业务功能或业务需求
- 开发简单、开发效率提高，一个服务可能就是专一的只干一件事，因此可以被小团队单独开发，通常2-5人就可以
- 微服务可以使用不同的语言开发，就是说这个微服务可以使用 Java 语言开发，另外一个可以使用 Python 语言开发，只要两个服务可以通过 Http 调用即可
- 易和第三方集成，且部署灵活，可以和 Docker Jenkins Hudson 配合
- 微服务只是业务逻辑代码，不会和 Html CSS 混合，前后端分离
- 每个微服务都有自己的存储能力，可以有自己的数据库，也可以使用统一数据库
#### 缺点
- 开发人员需要处理分布式系统的复杂性
- 运维工作加大，服务越多，运维越困难
- 服务间的通信成本
- 性能监控
- 事务等

### 微服务技术栈
- 服务配置与管理：Netflix 的 Archaius、阿里的 Diamond
- 注册与发现：Eureka、Consul、Zookeeper、Nacos
- 调用：Rest、RPC、gRPC
- 熔断器：Hystrix、Envoy
- 负载均衡：Ribbon、Nginx
- 服务接口调用：Feign
- 消息队列：Kafka、RabbitMQ、ActiveMQ
- 配置管理中心：SpringCloud Config、Nacos
- 路由网关：Zuul
- 服务监控：Zabbix、Nagios、Metrics
- 全链路追踪：Zipkin、Brave、Dapper
- 服务部署：Docker、OpenStack、Kubernetes
- 等等

### 为什么选则 SpringCloud ？
相比其他微服务框架来说，SpringCloud（SC）提供了一站式整体解决方案、且框架成熟，社区热度高，可维护性强，学习不复杂

比如说阿里的 Dubbo，HSF，或者是京东的 JSF，新浪的微博 Motan，当当网的 DubboX等

### 微服务框架对比
![mark](http://7niu.chensr.cn/blog/20190705/eiSyT2ICY7RW.png?imageslim)


