title: Spring Cloud入门（10）- SC总结
date: '2019-07-11 21:06:10'
updated: '2019-07-11 21:06:10'
tags: [微服务, SC, SpringCloud, SOA]
permalink: /articles/2019/07/11/1562850370707.html
---
![](http://7niu.chensr.cn/blog/20190709/vHyRIOCTIhaj.png?imageslim)

#### 梳理
整套开发技术栈以 SpringCloud 为主，单个微服务模块以 SpringMVC+SpringBoot/Spring+MyBatis 组合进行开发。

前端层，页面 H5+thymeleaf/ 样式 CSS3+Bootstrap/ 前端框架JQuery+Node|Vue等。

负载层，前端访问通过 Http 或 Https 协议到达服务端的 LB，可以是 F5 等硬件做负载均衡，还可以自行部署LVS + Keepalived 等（前期量小可以直接使用 Nginx） 

网关层，请求通过 LB 后，会到达整个微服务体系的网关层 Zuul（Gateway），内嵌 Ribbon 做客户端负载均衡， Hystrix 做熔断降级等。

服务注册，采用 Eureka 来做服务治理，Zuul 会从 Eureka 集群获取已发布的微服务访问地址，然后根据配置把请求代理到相应的微服务去。

docker 容器，所有的微服务模块都部署在 Docker 容器里面，而且前后端的服务完全分开，各自独立部署后前端微服务调用后端微服务，后端微服务之间会有相互调用。

服务调用，微服务模块间调用都采用标准的 Http/Https+REST+JSON 的方式，调用技术采用 Feign+HttpClient+Ribbon+Hystrix。

统一配置，每个微服务模块会跟 Eureka 集群、配置中心（SpringCloudConfig）等进行交互。

第3方框架，每个微服务模块根据实现的需要，通常还需要使用一些第三发框架，比如常见的有：缓存服务（Redis）、图片服务（FastDFS）、搜索服务（ElasticSearch）、安全管理（Shiro）等等。

Mysql 数据库，可以按照微服务模块进行拆分，统一访问公共库或者单独自己库，可以单独构建 MySQL 集群或者分库分表 MyCat 等。