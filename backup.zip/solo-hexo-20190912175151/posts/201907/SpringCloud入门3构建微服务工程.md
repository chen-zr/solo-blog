title: Spring Cloud入门（3）- 构建微服务工程
date: '2019-07-09 20:52:08'
updated: '2019-07-09 21:36:01'
tags: [微服务, SC, SpringCloud, SOA]
permalink: /articles/2019/07/09/1562676728713.html
---
![](http://7niu.chensr.cn/blog/20190709/vHyRIOCTIhaj.png?imageslim)

### 工程目录
微服务的目录结构，通常是一个父项目，带着多个 Module 子模块，父项目的 pom 属性为 pom，子 module 的 pom 属性为 jar。

#### 目录结构
- microservicecloud-api（封装的整体entity/接口/公共配置等）
- microservicecloud-provider-dept-8001（微服务落地的服务提供者）
- microservicecloud-consumer-dept-80（微服务调用的客户端使用）

#### 开始构建
##### microservicecloud 整体父工程 Project
Packaging 是 pom 模式，其他公共包部分略。
```xml
<groupId>com.atguigu.springcloud</groupId>
<artifactId>microservicecloud</artifactId>
<version>0.0.1-SNAPSHOT</version>
<packaging>pom</packaging>
```
##### microservicecloud-api 公共子模块 Module
在父工程下，新建子模块 microservicecloud-api，pom 如下，其他公共包部分略过。
```xml
<!-- 子类里面显示声明才能有明确的继承表现，无意外就是父类的默认版本否则自己定义 -->
<parent>
    <groupId>com.atguigu.springcloud</groupId>
    <artifactId>microservicecloud</artifactId>
    <version>0.0.1-SNAPSHOT</version>
</parent>

<!-- 当前Module我自己叫什么名字 -->
<artifactId>microservicecloud-api</artifactId>
```
新建部门 entity 配合 lombok 使用
```java
package com.atguigu.springcloud.entities;
import java.io.Serializable;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
 
@SuppressWarnings("serial")
@NoArgsConstructor
@Data
@Accessors(chain=true)
//必须序列化
public class Dept implements Serializable {
	private Long deptno;
	private String dname;
	//来自那个数据库，因为微服务架构可以一个服务对应一个数据库，同一个信息被存储到不同数据库
	private String db_source;
	public Dept(String dname) {
		super();
		this.dname = dname;
	}
}
```
mvn clean install

##### microservicecloud-provider-dept-8001  部门微服务提供者Module
在父工程下，新建子模块 microservicecloud-provider-dept-8001，pom 如下，其他公共包部分略过。
```xml
<parent>
    <groupId>com.atguigu.springcloud</groupId>
    <artifactId>microservicecloud</artifactId>
    <version>0.0.1-SNAPSHOT</version>
</parent>

<!-- 当前Module我自己叫什么名字 -->
<artifactId>microservicecloud-provider-dept-8001</artifactId>
```

yml 配置文件
```yml
server:
  port: 8001
  
mybatis:
  config-location: classpath:mybatis/mybatis.cfg.xml        # mybatis配置文件所在路径
  type-aliases-package: com.atguigu.springcloud.entities    # 所有Entity别名类所在包
  mapper-locations:
  - classpath:mybatis/mapper/**/*.xml                       # mapper映射文件
    
spring:
   application:
    name: microservicecloud-dept 
   datasource:
    type: com.alibaba.druid.pool.DruidDataSource            # 当前数据源操作类型
    driver-class-name: org.gjt.mm.mysql.Driver              # mysql驱动包
    url: jdbc:mysql://localhost:3306/cloudDB01              # 数据库名称
    username: root
    password: 123456
    dbcp2:
      min-idle: 5                                           # 数据库连接池的最小维持连接数
      initial-size: 5                                       # 初始化连接数
      max-total: 5                                          # 最大连接数
      max-wait-millis: 200                                  # 等待连接获取的最大超时时间
```
mybatis.cfg.xml 略
sql如下：

```sql
DROP DATABASE IF EXISTS cloudDB01;
CREATE DATABASE cloudDB01 CHARACTER SET UTF8;
USE cloudDB01;
CREATE TABLE dept (
  deptno BIGINT NOT NULL PRIMARY KEY AUTO_INCREMENT,
  dname VARCHAR(60),
  db_source   VARCHAR(60)
);
 
INSERT INTO dept(dname,db_source) VALUES('开发部',DATABASE());
INSERT INTO dept(dname,db_source) VALUES('人事部',DATABASE());
INSERT INTO dept(dname,db_source) VALUES('财务部',DATABASE());
INSERT INTO dept(dname,db_source) VALUES('市场部',DATABASE());
INSERT INTO dept(dname,db_source) VALUES('运维部',DATABASE());
```
DeptDao 部门接口：
```java
package com.atguigu.springcloud.dao;
 
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import com.atguigu.springcloud.entities.Dept;
 
@Mapper
public interface DeptDao {
  public boolean addDept(Dept dept);
  public Dept findById(Long id);
  public List<Dept> findAll();
}
```
DeptMapper.xml
```xml
<mapper namespace="com.atguigu.springcloud.dao.DeptDao">
  <select id="findById" resultType="Dept" parameterType="Long">
    select deptno,dname,db_source from dept where deptno=#{deptno}; 
  </select>
  <select id="findAll" resultType="Dept">
    select deptno,dname,db_source from dept; 
  </select>
  <insert id="addDept" parameterType="Dept">
    INSERT INTO dept(dname,db_source) VALUES(#{dname},DATABASE());
  </insert>
</mapper>
```
DeptService 部门服务接口
```java
package com.atguigu.springcloud.service;
import java.util.List;
import com.atguigu.springcloud.entities.Dept;
public interface DeptService {
    public boolean add(Dept dept);
    public Dept get(Long id);
    public List<Dept> list();
}
```
DeptServiceImpl 部门服务接口实现类
```java
package com.atguigu.springcloud.service.impl;
 
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.atguigu.springcloud.dao.DeptDao;
import com.atguigu.springcloud.entities.Dept;
import com.atguigu.springcloud.service.DeptService;

@Service
public class DeptServiceImpl implements DeptService {
  @Autowired
  private DeptDao dao ;
 
  @Override
  public boolean add(Dept dept){
    return dao.addDept(dept);
  }
 
  @Override
  public Dept get(Long id) {
    return dao.findById(id);
  }
 
  @Override
  public List<Dept> list() {
    return dao.findAll();
  }
}
```
DeptController 部门微服务提供者 REST
```java
package com.atguigu.springcloud.controller;
 
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.atguigu.springcloud.entities.Dept;
import com.atguigu.springcloud.service.DeptService;
 
@RestController
public class DeptController {
  @Autowired
  private DeptService service;
  
  @RequestMapping(value="/dept/add",method=RequestMethod.POST)
  public boolean add(@RequestBody Dept dept) {
    return service.add(dept);
  }
  
  @RequestMapping(value="/dept/get/{id}",method=RequestMethod.GET)
  public Dept get(@PathVariable("id") Long id) {
    return service.get(id);
  }
  
  @RequestMapping(value="/dept/list",method=RequestMethod.GET)
  public List<Dept> list(){
    return service.list();
  }
}
```
DeptProvider8001_App 主启动类
```java
package com.atguigu.springcloud;
 
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
 
@SpringBootApplication
public class DeptProvider8001_App {
  public static void main(String[] args) {
    SpringApplication.run(DeptProvider8001_App.class, args);
  }
}
```
测试：
http://localhost:8001/dept/get/2
http://localhost:8001/dept/list

![mark](http://7niu.chensr.cn/blog/20190705/9e2Dwh4G1pnX.png?imageslim)

##### microservicecloud-consumer-dept-80 部门微服务消费者Module
新建 microservicecloud-consumer-dept-80，pom 如下，其他公共部分略
```xml
<parent>
    <groupId>com.atguigu.springcloud</groupId>
    <artifactId>microservicecloud</artifactId>
    <version>0.0.1-SNAPSHOT</version>
</parent>

<!-- 当前Module我自己叫什么名字 -->
<artifactId>microservicecloud-consumer-dept-80</artifactId>
<description>部门微服务消费者</description>
```
yml 配置文件
```yml
server:
  port: 80
```

com.atguigu.springcloud.cfgbeans 包下 ConfigBean 的编写（类似 spring 里面的 applicationContext.xml 写入的注入Bean）

RestTemplate 提供了多种便捷访问远程 Http 服务的方法，是一种简单便捷的访问 restful 服务模板类，是 Spring 提供的用于访问 Rest 服务的客户端模板工具集
```java
package com.atguigu.springcloud.cfgbeans;
 
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;
 
@Configuration
public class ConfigBean {
    @Bean
    public RestTemplate getRestTemplate() {
         return new RestTemplate();
    }
}
```
com.atguigu.springcloud.controller 包下新建 DeptController_Consumer 部门微服务消费者 REST
```java
package com.atguigu.springcloud.controller;
 
import java.util.List;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
 
import com.atguigu.springcloud.entities.Dept;
 
@RestController
public class DeptController_Consumer {
    private static final String REST_URL_PREFIX = "http://localhost:8001";
    
    @Autowired
    private RestTemplate restTemplate;
    
    @RequestMapping(value="/consumer/dept/add")
    public boolean add(Dept dept) {
         return restTemplate.postForObject(REST_URL_PREFIX+"/dept/add", dept, Boolean.class);
    }
    
    @RequestMapping(value="/consumer/dept/get/{id}")
    public Dept get(@PathVariable("id") Long id) {
         return restTemplate.getForObject(REST_URL_PREFIX+"/dept/get/"+id, Dept.class);
    }
    
    @SuppressWarnings("unchecked")
    @RequestMapping(value="/consumer/dept/list")
    public List<Dept> list() {
         return restTemplate.getForObject(REST_URL_PREFIX+"/dept/list", List.class);
    }   
}
```
DeptConsumer80_App 主启动类
```java
package com.atguigu.springcloud;
 
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DeptConsumer80_App {
  public static void main(String[] args) {
    SpringApplication.run(DeptConsumer80_App.class, args);
  }
}
```

测试：
http://localhost/consumer/dept/get/2 
http://localhost/consumer/dept/list 
http://localhost/consumer/dept/add?dname=AI 

